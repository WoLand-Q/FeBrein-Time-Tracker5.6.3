<?php

namespace App\Services\Admin;

use App\Models\User;
use App\Models\UserTimeLog;
use Illuminate\Support\Facades\Auth;

class UserTimeLogService
{
    public function store(array $data): UserTimeLog
    {
        $user_time_log = new UserTimeLog();
        $user_time_log->fill($data);
        $user_time_log->user_id = Auth::id();
        $user_time_log->save();
        //тут перевіряти тип події, викликати сервіс ЮзерВоркДейс, передавати всі дані, та робити там усю калькуляцію
        //також потрібно використовувати транзакції чи краще у сервісі
        return $user_time_log;
    }

    public function update(UserTimeLog $user_time_log, array $data): UserTimeLog
    {

        $user_time_log->fill($data);
        $user_time_log->save();

        return $user_time_log;
    }

    public function destroy(UserTimeLog $user_time_log): bool
    {
        return $user_time_log->delete();
    }
}
