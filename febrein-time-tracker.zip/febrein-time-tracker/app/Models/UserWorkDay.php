<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserWorkDay extends Model
{
    protected $fillable = [
        'user_id',
        'date',
        'work_minutes',
        'break_minutes',
        'work_started_at',
        'work_ended_at',
        'break_started_at',
        'break_ended_at',
    ];

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}
