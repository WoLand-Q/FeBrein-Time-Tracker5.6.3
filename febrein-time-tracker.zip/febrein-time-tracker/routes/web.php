<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\AuthenticatedSessionController;



Route::get('/login', function () {
    return view('auth.login');
})->name('login');


Route::post('/login', [AuthenticatedSessionController::class, 'store']);

Route::get('/{any}', function () {
    return view('app');
})->where('any', '.*');
