<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>My SPA</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
</head>
<body>
<div id="app"></div>
</body>
</html>
<?php /**PATH C:\Users\Game-On-Dp\Desktop\FeBrein-Time-Tracker-5.0\febrein-time-tracker\resources\views/app.blade.php ENDPATH**/ ?>