<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>My SPA</title>
    @vite('resources/js/app.js')
</head>
<body>
<div id="app"></div>
</body>
</html>
