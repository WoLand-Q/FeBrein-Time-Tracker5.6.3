<!-- components/UserForm.vue -->
<template>
    <form @submit.prevent="submitForm" class="space-y-6">
        <div>
            <label for="name" class="block text-sm font-medium text-gray-300">Name</label>
            <input
                v-model="formData.name"
                id="name"
                type="text"
                required
                class="mt-1 block w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary text-white placeholder-gray-400"
                placeholder="Enter name"
            />
            <p v-if="errors.name" class="mt-1 text-sm text-red-600 animate__animated animate__fadeIn">
                {{ errors.name }}
            </p>
        </div>

        <div>
            <label for="login" class="block text-sm font-medium text-gray-300">Login</label>
            <input
                v-model="formData.login"
                id="login"
                type="text"
                required
                class="mt-1 block w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary text-white placeholder-gray-400"
                placeholder="Enter login"
            />
            <p v-if="errors.login" class="mt-1 text-sm text-red-600 animate__animated animate__fadeIn">
                {{ errors.login }}
            </p>
        </div>

        <div>
            <label for="role" class="block text-sm font-medium text-gray-300">Role</label>
            <select
                v-model="formData.role"
                id="role"
                required
                class="mt-1 block w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary text-white"
            >
                <option value="admin">Admin</option>
                <option value="user">User</option>
            </select>
            <p v-if="errors.role" class="mt-1 text-sm text-red-600 animate__animated animate__fadeIn">
                {{ errors.role }}
            </p>
        </div>

        <div class="flex justify-end space-x-2">
            <BaseButton type="submit" variant="primary">Save</BaseButton>
            <BaseButton type="button" variant="secondary" @click="resetForm">Reset</BaseButton>
        </div>
    </form>
</template>

<script>
import BaseButton from "./BaseButton.vue";

export default {
    name: "UserForm",
    components: { BaseButton },
    props: {
        formData: {
            type: Object,
            default: () => ({
                name: "",
                login: "",
                role: "user",
            }),
        },
    },
    data() {
        return {
            errors: {},
        };
    },
    methods: {
        submitForm() {
            this.errors = {};
            let isValid = true;

            if (!this.formData.name) {
                this.errors.name = "Name is required.";
                isValid = false;
            }

            if (!this.formData.login) {
                this.errors.login = "Login is required.";
                isValid = false;
            }

            if (!this.formData.role) {
                this.errors.role = "Role is required.";
                isValid = false;
            }

            if (isValid) {
                this.$emit("submit", this.formData);
            }
        },
        resetForm() {
            this.$emit("reset");
        },
    },
};
</script>

<style scoped>
/* Нет необходимости в дополнительных стилях благодаря Tailwind CSS */
</style>
