<!-- pages/AdminPanel.vue -->
<template>
    <div>
        <!-- Alert Notification -->
        <Alert
            :type="alert.type"
            :title="alert.title"
            :message="alert.message"
            :show="alert.show"
        />

        <div class="space-y-6">
            <!-- Users Management -->
            <div class="bg-background p-6 rounded-lg shadow-md transition-transform transform hover:scale-105">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="text-2xl font-semibold text-text">Manage Users</h2>
                    <BaseButton variant="primary" @click="openUserModal">
                        <i class="fas fa-plus mr-2"></i> Add User
                    </BaseButton>
                </div>
                <TableComponent
                    :items="users"
                    :columns="['Name', 'Login', 'Role', 'Actions']"
                    @edit="editUser"
                    @delete="deleteUser"
                />
            </div>

            <!-- Groups Management -->
            <div class="bg-background p-6 rounded-lg shadow-md transition-transform transform hover:scale-105">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="text-2xl font-semibold text-text">Manage Groups</h2>
                    <BaseButton variant="secondary" @click="openGroupModal">
                        <i class="fas fa-plus mr-2"></i> Add Group
                    </BaseButton>
                </div>
                <TableComponent
                    :items="groups"
                    :columns="['Name', 'Actions']"
                    @edit="editGroup"
                    @delete="deleteGroup"
                />
            </div>

            <!-- Time Logs Management -->
            <div class="bg-background p-6 rounded-lg shadow-md transition-transform transform hover:scale-105">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="text-2xl font-semibold text-text">Manage Time Logs</h2>
                    <BaseButton variant="warning" @click="openTimeLogModal">
                        <i class="fas fa-plus mr-2"></i> Add Time Log
                    </BaseButton>
                </div>
                <TableComponent
                    :items="timeLogs"
                    :columns="['User', 'Event', 'Date', 'Actions']"
                    @edit="editTimeLog"
                    @delete="deleteTimeLog"
                />
            </div>

            <!-- Modals for CRUD Operations -->
            <!-- Users Modal -->
            <Modal v-if="showUserModal" @close="closeUserModal">
                <template #title>
                    <span v-if="currentUser" class="text-xl font-semibold">Edit User</span>
                    <span v-else class="text-xl font-semibold">Add User</span>
                </template>
                <template #body>
                    <UserForm :formData="userForm" @submit="saveUser" @reset="resetUserForm" />
                </template>
                <template #actions>
                    <BaseButton variant="danger" @click="closeUserModal">Cancel</BaseButton>
                </template>
            </Modal>

            <!-- Groups Modal -->
            <Modal v-if="showGroupModal" @close="closeGroupModal">
                <template #title>
                    <span v-if="currentGroup" class="text-xl font-semibold">Edit Group</span>
                    <span v-else class="text-xl font-semibold">Add Group</span>
                </template>
                <template #body>
                    <GroupForm :formData="groupForm" @submit="saveGroup" @reset="resetGroupForm" />
                </template>
                <template #actions>
                    <BaseButton variant="danger" @click="closeGroupModal">Cancel</BaseButton>
                </template>
            </Modal>

            <!-- Time Logs Modal -->
            <Modal v-if="showTimeLogModal" @close="closeTimeLogModal">
                <template #title>
                    <span v-if="currentTimeLog" class="text-xl font-semibold">Edit Time Log</span>
                    <span v-else class="text-xl font-semibold">Add Time Log</span>
                </template>
                <template #body>
                    <TimeLogForm :formData="timeLogForm" @submit="saveTimeLog" @reset="resetTimeLogForm" />
                </template>
                <template #actions>
                    <BaseButton variant="danger" @click="closeTimeLogModal">Cancel</BaseButton>
                </template>
            </Modal>
        </div>
    </div>
</template>

<script>
import api from "../api";
import Modal from "../components/Modal.vue";
import TableComponent from "../components/TableComponent.vue";
import UserForm from "../components/UserForm.vue";
import GroupForm from "../components/GroupForm.vue";
import TimeLogForm from "../components/TimeLogForm.vue";
import BaseButton from "../components/BaseButton.vue";
import Alert from "../components/Alert.vue";

export default {
    name: "AdminPanel",
    components: {
        Modal,
        TableComponent,
        UserForm,
        GroupForm,
        TimeLogForm,
        BaseButton,
        Alert,
    },
    data() {
        return {
            users: [],
            groups: [],
            timeLogs: [],
            showUserModal: false,
            showGroupModal: false,
            showTimeLogModal: false,
            currentUser: null,
            currentGroup: null,
            currentTimeLog: null,
            userForm: { id: null, name: "", login: "", role: "user" },
            groupForm: { id: null, name: "" },
            timeLogForm: { id: null, user_id: "", event_id: "", acted_at: "" },
            alert: {
                show: false,
                type: "success",
                title: "",
                message: "",
            },
        };
    },
    methods: {
        async fetchData() {
            try {
                const [usersRes, groupsRes, timeLogsRes] = await Promise.all([
                    api.get("api/admin/users"),
                    api.get("api/admin/groups"),
                    api.get("api/admin/userTimeLogs"),
                ]);
                // Предполагаем, что данные находятся в usersRes.data, groupsRes.data и timeLogsRes.data
                this.users = usersRes.data.data || usersRes.data;
                this.groups = groupsRes.data.data || groupsRes.data;
                this.timeLogs = timeLogsRes.data.data || timeLogsRes.data;
            } catch (error) {
                console.error("Error fetching data:", error);
                this.triggerAlert("error", "Ошибка", "Не удалось загрузить данные.");
            }
        },
        // Методы для управления пользователями
        openUserModal(user = null) {
            this.currentUser = user;
            this.userForm = user
                ? { ...user }
                : { id: null, name: "", login: "", role: "user" };
            this.showUserModal = true;
        },
        closeUserModal() {
            this.showUserModal = false;
            this.resetUserForm();
        },
        resetUserForm() {
            this.userForm = { id: null, name: "", login: "", role: "user" };
        },
        async saveUser(formData) {
            try {
                if (formData.id) {
                    await api.put(`/admin/users/${formData.id}`, formData);
                    this.triggerAlert("success", "Успешно", "Пользователь обновлен.");
                } else {
                    await api.post("/admin/users", formData);
                    this.triggerAlert("success", "Успешно", "Пользователь добавлен.");
                }
                this.fetchData();
                this.closeUserModal();
            } catch (error) {
                console.error("Error saving user:", error);
                this.triggerAlert("error", "Ошибка", "Не удалось сохранить пользователя.");
            }
        },
        async deleteUser(userId) {
            if (confirm("Are you sure you want to delete this user?")) {
                try {
                    await api.delete(`/admin/users/${userId}`);
                    this.triggerAlert("success", "Успешно", "Пользователь удален.");
                    this.fetchData();
                } catch (error) {
                    console.error("Error deleting user:", error);
                    this.triggerAlert("error", "Ошибка", "Не удалось удалить пользователя.");
                }
            }
        },
        editUser(user) {
            this.openUserModal(user);
        },

        // Методы для управления группами
        openGroupModal(group = null) {
            this.currentGroup = group;
            this.groupForm = group
                ? { ...group }
                : { id: null, name: "" };
            this.showGroupModal = true;
        },
        closeGroupModal() {
            this.showGroupModal = false;
            this.resetGroupForm();
        },
        resetGroupForm() {
            this.groupForm = { id: null, name: "" };
        },
        async saveGroup(formData) {
            try {
                if (formData.id) {
                    await api.put(`/admin/groups/${formData.id}`, formData);
                    this.triggerAlert("success", "Успешно", "Группа обновлена.");
                } else {
                    await api.post("/admin/groups", formData);
                    this.triggerAlert("success", "Успешно", "Группа добавлена.");
                }
                this.fetchData();
                this.closeGroupModal();
            } catch (error) {
                console.error("Error saving group:", error);
                this.triggerAlert("error", "Ошибка", "Не удалось сохранить группу.");
            }
        },
        async deleteGroup(groupId) {
            if (confirm("Are you sure you want to delete this group?")) {
                try {
                    await api.delete(`/admin/groups/${groupId}`);
                    this.triggerAlert("success", "Успешно", "Группа удалена.");
                    this.fetchData();
                } catch (error) {
                    console.error("Error deleting group:", error);
                    this.triggerAlert("error", "Ошибка", "Не удалось удалить группу.");
                }
            }
        },
        editGroup(group) {
            this.openGroupModal(group);
        },

        // Методы для управления таймлогами
        openTimeLogModal(timeLog = null) {
            this.currentTimeLog = timeLog;
            this.timeLogForm = timeLog
                ? { ...timeLog }
                : { id: null, user_id: "", event_id: "", acted_at: "" };
            this.showTimeLogModal = true;
        },
        closeTimeLogModal() {
            this.showTimeLogModal = false;
            this.resetTimeLogForm();
        },
        resetTimeLogForm() {
            this.timeLogForm = { id: null, user_id: "", event_id: "", acted_at: "" };
        },
        async saveTimeLog(formData) {
            try {
                if (formData.id) {
                    await api.put(`/admin/userTimeLogs/${formData.id}`, formData);
                    this.triggerAlert("success", "Успешно", "Таймлог обновлен.");
                } else {
                    await api.post("/admin/userTimeLogs", formData);
                    this.triggerAlert("success", "Успешно", "Таймлог добавлен.");
                }
                this.fetchData();
                this.closeTimeLogModal();
            } catch (error) {
                console.error("Error saving time log:", error);
                this.triggerAlert("error", "Ошибка", "Не удалось сохранить таймлог.");
            }
        },
        async deleteTimeLog(timeLogId) {
            if (confirm("Are you sure you want to delete this time log?")) {
                try {
                    await api.delete(`/admin/userTimeLogs/${timeLogId}`);
                    this.triggerAlert("success", "Успешно", "Таймлог удален.");
                    this.fetchData();
                } catch (error) {
                    console.error("Error deleting time log:", error);
                    this.triggerAlert("error", "Ошибка", "Не удалось удалить таймлог.");
                }
            }
        },
        editTimeLog(timeLog) {
            this.openTimeLogModal(timeLog);
        },

        // Метод для отображения уведомлений
        triggerAlert(type, title, message) {
            this.alert = { show: true, type, title, message };
            setTimeout(() => {
                this.alert.show = false;
            }, 3000);
        },
    },
    mounted() {
        this.fetchData();
    },
};
</script>

<style scoped>
/* Используем Tailwind CSS для стилизации и анимаций */

/* Переходы для модальных окон */
.modal-enter-active,
.modal-leave-active {
    @apply transition-opacity duration-300;
}
.modal-enter,
.modal-leave-to {
    @apply opacity-0;
}

/* Улучшаем таблицы */
.table-container {
    @apply overflow-x-auto;
}
.table {
    @apply min-w-full divide-y divide-gray-700;
}
.table th,
.table td {
    @apply px-6 py-4;
}
.table th {
    @apply bg-background-light text-left text-xs font-medium text-text uppercase tracking-wider;
}
.table tr {
    @apply bg-background;
}
.table tr:hover {
    @apply bg-background-light;
}

/* Responsive Design */
@media (max-width: 768px) {
    .flex {
        @apply flex-col;
    }
}

/* Переходы для Alert */
.fade-enter-active, .fade-leave-active {
    transition: opacity 0.5s;
}
.fade-enter-from, .fade-leave-to {
    opacity: 0;
}
</style>
