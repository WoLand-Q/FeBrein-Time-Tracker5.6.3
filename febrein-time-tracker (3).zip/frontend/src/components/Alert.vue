<!-- components/Alert.vue -->
<template>
    <div
        v-if="show"
        :class="alertClasses"
        role="alert"
    >
        <span class="font-medium">{{ title }}</span>
        <span>{{ message }}</span>
    </div>
</template>

<script>
export default {
    name: "Alert",
    props: {
        type: {
            type: String,
            default: "success", // варианты: success, error, warning, info
        },
        title: {
            type: String,
            default: "",
        },
        message: {
            type: String,
            default: "",
        },
        show: {
            type: Boolean,
            default: false,
        },
    },
    computed: {
        alertClasses() {
            const base =
                "flex items-center p-4 mb-4 text-sm rounded-lg shadow-md";
            const types = {
                success: "text-green-700 bg-green-100",
                error: "text-red-700 bg-red-100",
                warning: "text-yellow-700 bg-yellow-100",
                info: "text-blue-700 bg-blue-100",
            };
            return `${base} ${types[this.type] || types.info}`;
        },
    },
};
</script>

<style scoped>
/* Нет необходимости в дополнительных стилях благодаря Tailwind CSS */
</style>

