<!-- components/TableComponent.vue -->
<template>
    <div class="table-container">
        <table class="table">
            <thead class="bg-background-light">
            <tr>
                <th v-for="column in columns" :key="column" class="text-left text-xs font-medium text-text uppercase tracking-wider">
                    {{ column }}
                </th>
            </tr>
            </thead>
            <tbody class="bg-background divide-y divide-gray-700">
            <tr v-for="item in items" :key="item.id" class="hover:bg-background-light transition-colors duration-200">
                <td class="px-6 py-4 whitespace-nowrap">
                    <!-- Динамический контент в зависимости от колонки -->
                    <span v-if="columnMapping.Name">{{ getProperty(item, 'name') }}</span>
                    <span v-if="columnMapping.Login">{{ getProperty(item, 'login') }}</span>
                    <span v-if="columnMapping.Role">{{ getProperty(item, 'role') }}</span>
                    <span v-if="columnMapping.User">{{ getUserName(item.user_id) }}</span>
                    <span v-if="columnMapping.Event">{{ getEventName(item.event_id) }}</span>
                    <span v-if="columnMapping.Date">{{ formatDate(item.acted_at) }}</span>
                </td>
                <td v-if="isActionColumn" class="px-6 py-4 whitespace-nowrap">
                    <div class="flex space-x-2">
                        <BaseButton variant="warning" size="sm" @click="$emit('edit', item)">Edit</BaseButton>
                        <BaseButton variant="danger" size="sm" @click="$emit('delete', item.id)">Delete</BaseButton>
                    </div>
                </td>
            </tr>
            </tbody>
        </table>
    </div>
</template>

<script>
import BaseButton from "./BaseButton.vue";

export default {
    name: "TableComponent",
    components: { BaseButton },
    props: {
        items: {
            type: Array,
            required: true,
        },
        columns: {
            type: Array,
            required: true,
        },
    },
    computed: {
        isActionColumn() {
            return this.columns.includes("Actions");
        },
        columnMapping() {
            const mapping = {};
            this.columns.forEach((col) => {
                mapping[col] = true;
            });
            return mapping;
        },
    },
    methods: {
        getProperty(item, prop) {
            return item[prop] || '-';
        },
        getUserName(userId) {
            return userId ? `User ID: ${userId}` : '-';
        },
        getEventName(eventId) {
            return eventId ? `Event ID: ${eventId}` : '-';
        },
        formatDate(date) {
            if (!date) return '-';
            const options = { year: 'numeric', month: 'short', day: 'numeric' };
            return new Date(date).toLocaleDateString(undefined, options);
        },
    },
};
</script>

<style scoped>
.table-container {
    @apply overflow-x-auto;
}
.table {
    @apply min-w-full divide-y divide-gray-700;
}
.table th,
.table td {
    @apply px-6 py-4;
}
.table th {
    @apply bg-background-light text-left text-xs font-medium text-text uppercase tracking-wider;
}
.table tr {
    @apply bg-background;
}
.table tr:hover {
    @apply bg-background-light;
}
</style>
