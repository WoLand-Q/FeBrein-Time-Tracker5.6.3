// api.js
import axios from "axios";

const token = localStorage.getItem("token");
const headers = {};

if (token) {
    headers["Authorization"] = `Bearer ${token}`;
}

const api = axios.create({
    baseURL: "http://127.0.0.1:8000",
    headers: headers,
    withCredentials: true,
});


async function initializeCsrf() {
    // Используем полный URL без "/api"
    await axios.get("http://127.0.0.1:8000/sanctum/csrf-cookie", { withCredentials: true });
}

export default api;
