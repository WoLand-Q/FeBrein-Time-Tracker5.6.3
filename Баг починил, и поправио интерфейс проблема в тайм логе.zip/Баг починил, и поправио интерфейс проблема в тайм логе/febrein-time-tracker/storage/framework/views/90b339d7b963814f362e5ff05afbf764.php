<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My App</title>
    <?php echo app('Illuminate\Foundation\Vite')('frontend/src/main.js'); ?> <!-- Подключение Vite -->
</head>
<body>
<div id="app"></div> <!-- Корневой элемент Vue -->
</body>
</html>
<?php /**PATH C:\Users\Game-On-Dp\Desktop\FeBrein-Time-Tracker-5.0\febrein-time-tracker\resources\views/app.blade.php ENDPATH**/ ?>