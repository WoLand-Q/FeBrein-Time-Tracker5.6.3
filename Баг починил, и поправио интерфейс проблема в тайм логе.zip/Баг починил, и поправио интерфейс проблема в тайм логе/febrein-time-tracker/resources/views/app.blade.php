<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My App</title>
    @vite('frontend/src/main.js') <!-- Подключение Vite -->
</head>
<body>
<div id="app"></div> <!-- Корневой элемент Vue -->
</body>
</html>
