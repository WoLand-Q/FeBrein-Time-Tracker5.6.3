<template>
  <div class="overflow-x-auto">
    <table class="min-w-full text-sm">
      <thead>
      <tr class="bg-gray-700 text-white uppercase text-xs">
        <th
            v-for="col in columns"
            :key="col"
            class="px-4 py-2 text-left"
        >
          {{ col }}
        </th>
      </tr>
      </thead>
      <tbody>
      <tr
          v-for="item in items"
          :key="item.id"
          class="border-b border-gray-700 hover:bg-gray-700"
      >
        <td
            v-for="col in columns"
            :key="col"
            class="px-4 py-2 whitespace-nowrap"
        >
          <!-- USERS TABLE -->
          <template v-if="col === 'Name' && tableType==='users'">
            {{ item.name || '-' }}
          </template>
          <template v-else-if="col === 'Login' && tableType==='users'">
            {{ item.login || '-' }}
          </template>
          <template v-else-if="col === 'Role' && tableType==='users'">
            {{ item.role_name || '-' }}
          </template>
          <template v-else-if="col === 'Group' && tableType==='users'">
            {{ item.group_name || getGroupName(item.group_id) }}
          </template>

          <!-- GROUPS TABLE -->
          <template v-else-if="col === 'Name' && tableType==='groups'">
            {{ item.group_name || '-' }}
          </template>

          <!-- TIMELOGS TABLE (пример) -->
          <template v-else-if="col === 'User' && tableType==='timelogs'">
            {{ getUserLogin(item.user_id) }}
          </template>
          <template v-else-if="col === 'Event' && tableType==='timelogs'">
            {{ item.even_name ? item.even_name : ('Event #' + item.event_id) }}
          </template>
          <template v-else-if="col === 'Date' && tableType==='timelogs'">
            {{ item.acted_at || '-' }}
          </template>

          <!-- ACTIONS -->
          <template v-else-if="col === 'Actions'">
            <div class="flex space-x-2">
              <button
                  class="px-2 py-1 rounded bg-yellow-500 text-white hover:bg-yellow-600"
                  @click="$emit('edit', item)"
              >
                Edit
              </button>
              <button
                  class="px-2 py-1 rounded bg-red-600 text-white hover:bg-red-700"
                  @click="$emit('delete', item.id)"
              >
                Delete
              </button>
            </div>
          </template>

          <!-- Default fallback -->
          <template v-else>
            {{ item[col] || '-' }}
          </template>
        </td>
      </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
  name: "TableComponent",
  props: {
    items: { type: Array, required: true },
    columns: { type: Array, required: true },
    tableType: { type: String, default: "" },
    users: { type: Array, default: () => [] },
    groups: { type: Array, default: () => [] },
  },
  methods: {
    getUserLogin(userId) {
      const user = this.users.find(u => u.id === userId);
      return user ? user.login : `User ID: ${userId}`;
    },
    getGroupName(groupId) {
      const grp = this.groups.find(g => g.id === groupId);
      return grp ? grp.group_name : `Group ID: ${groupId}`;
    },
  },
};
</script>

<style scoped>
/* стили */
</style>
