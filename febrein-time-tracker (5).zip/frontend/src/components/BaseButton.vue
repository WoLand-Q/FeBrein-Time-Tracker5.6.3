<template>
  <button
      :type="type"
      :class="buttonClasses"
      @click="$emit('click')"
  >
    <slot />
  </button>
</template>

<script>
export default {
  name: "BaseButton",
  props: {
    type: {type: String, default: "button"},
    variant: {type: String, default: "primary"},
    size: {type: String, default: "md"},
  },
  computed: {
    buttonClasses() {
      const base = `
        inline-flex items-center justify-center
        font-semibold rounded-full
        focus:outline-none focus:ring-2 focus:ring-offset-2
        transition-transform duration-200
        shadow-md
      `;

      // Пример «glass» фона
      const variants = {
        primary: "bg-red-500 hover:bg-red-600 text-white focus:ring-red-400",
        secondary: "bg-gray-700 hover:bg-gray-800 text-white focus:ring-gray-500",
        danger: "bg-red-700 hover:bg-red-800 text-white focus:ring-red-500",
        success: "bg-green-600 hover:bg-green-700 text-white focus:ring-green-400",
        warning: "bg-yellow-500 hover:bg-yellow-600 text-gray-900 focus:ring-yellow-400",
      };

      const sizes = {
        sm: "px-3 py-1 text-sm",
        md: "px-4 py-2 text-base",
        lg: "px-5 py-3 text-lg",
      };

      return [
        base,
        variants[this.variant] || variants.primary,
        sizes[this.size] || sizes.md,
      ].join(" ");
    },
  },
};
</script>
