<template>
  <form @submit.prevent="submitForm" class="space-y-4">
    <div>
      <label class="block text-sm font-medium mb-1 text-gray-300">Event</label>
      <select
          v-model="formData.event_id"
          class="w-full p-2 rounded bg-gray-700 border border-gray-600 text-white"
      >
        <option :value="1">Start Work</option>
        <option :value="2">Start Break</option>
        <option :value="3">End Break</option>
        <option :value="4">End Work</option>
      </select>
      <p v-if="errors.event_id" class="mt-1 text-sm text-red-600 animate__animated animate__fadeIn">
        {{ errors.event_id }}
      </p>
    </div>

    <div>
      <label class="block text-sm font-medium mb-1 text-gray-300">Acted At</label>
      <input
          v-model="formData.acted_at_local"
          type="datetime-local"
          class="w-full p-2 rounded bg-gray-700 border border-gray-600 text-white"
      />
      <p v-if="errors.acted_at" class="mt-1 text-sm text-red-600 animate__animated animate__fadeIn">
        {{ errors.acted_at }}
      </p>
    </div>

    <div class="flex justify-end space-x-2">
      <BaseButton type="submit" variant="warning">Save</BaseButton>
      <BaseButton type="button" variant="danger" @click="resetForm">Reset</BaseButton>
    </div>
  </form>
</template>

<script>
import BaseButton from "./BaseButton.vue";

export default {
  name: "TimeLogForm",
  components: { BaseButton },
  props: {
    formData: {
      type: Object,
      default: () => ({
        id: null,
        event_id: 1,
        acted_at: "",       // timestamp or string from DB
        acted_at_local: "", // локальное поле для datetime-local
      }),
    },
  },
  data() {
    return {
      errors: {},
    };
  },
  mounted() {
    // Если редактируем, сконвертируем acted_at (UTC) => локальный datetime
    if (this.formData.acted_at) {
      // Пример: 2023-09-01 14:30:00 => 2023-09-01T14:30
      const dateObj = new Date(this.formData.acted_at);
      this.formData.acted_at_local = dateObj.toISOString().slice(0,16);
    } else {
      // При создании нового, по умолчанию текущее время
      const now = new Date();
      this.formData.acted_at_local = now.toISOString().slice(0,16);
    }
  },
  methods: {
    submitForm() {
      this.errors = {};
      let isValid = true;

      // event_id обязателен
      if (!this.formData.event_id) {
        this.errors.event_id = "Event is required.";
        isValid = false;
      }

      // acted_at_local обязателен
      if (!this.formData.acted_at_local) {
        this.errors.acted_at = "Date/time is required.";
        isValid = false;
      }

      if (isValid) {
        // Преобразуем acted_at_local => timestamp (число)
        const dt = new Date(this.formData.acted_at_local);
        // Если пользователь выбрал 2023-09-05T10:30 => dt.getTime() / 1000
        const timestamp = Math.floor(dt.getTime() / 1000);

        // Запишем обратно в formData
        this.formData.acted_at = timestamp;

        // Убираем acted_at_local, чтобы не мешал на бэке
        delete this.formData.acted_at_local;

        this.$emit("submit", this.formData);
      }
    },
    resetForm() {
      this.$emit("reset");
    },
  },
};
</script>
