<template>
  <div class="space-y-6 fade-in">
    <!-- Alert Notification -->
    <Alert
        :type="alert.type"
        :title="alert.title"
        :message="alert.message"
        :show="alert.show"
    />

    <!-- Users Management -->
    <section class="panel-container hover-card">
      <div class="panel-header">
        <h2 class="panel-title">Manage Users</h2>
        <BaseButton variant="primary" @click="openUserModal">
          <i class="fas fa-plus mr-2"></i> Add User
        </BaseButton>
      </div>
      <TableComponent
          :items="users"
          :columns="['Name', 'Login', 'Role', 'Group', 'Actions']"
          tableType="users"
          :users="users"
          :groups="groups"
          @edit="editUser"
          @delete="deleteUser"
      />
    </section>

    <!-- Groups Management -->
    <section class="panel-container hover-card">
      <div class="panel-header">
        <h2 class="panel-title">Manage Groups</h2>
        <BaseButton variant="secondary" @click="openGroupModal">
          <i class="fas fa-plus mr-2"></i> Add Group
        </BaseButton>
      </div>
      <TableComponent
          :items="groups"
          :columns="['Name', 'Actions']"
          tableType="groups"
          @edit="editGroup"
          @delete="deleteGroup"
      />
    </section>

    <!-- Time Logs Management (пример) -->
    <section class="panel-container hover-card">
      <div class="panel-header">
        <h2 class="panel-title">Manage Time Logs</h2>
        <BaseButton variant="warning" @click="openTimeLogModal">
          <i class="fas fa-plus mr-2"></i> Add Time Log
        </BaseButton>
      </div>
      <TableComponent
          :items="timeLogs"
          :columns="['User', 'Event', 'Date', 'Actions']"
          tableType="timelogs"
          :users="users"
          @edit="editTimeLog"
          @delete="deleteTimeLog"
      />
    </section>

    <!-- Users Modal -->
    <Modal v-if="showUserModal" @close="closeUserModal">
      <template #title>
        <span class="text-xl font-semibold">
          {{ isEditingUser ? 'Edit User' : 'Add User' }}
        </span>
      </template>
      <template #body>
        <UserForm
            :formData="userForm"
            :groups="groups"
            @submit="saveUser"
            @reset="resetUserForm"
        />
      </template>
      <template #actions>
        <BaseButton variant="danger" @click="closeUserModal">Cancel</BaseButton>
      </template>
    </Modal>

    <!-- Groups Modal -->
    <Modal v-if="showGroupModal" @close="closeGroupModal">
      <template #title>
        <span class="text-xl font-semibold">
          {{ isEditingGroup ? 'Edit Group' : 'Add Group' }}
        </span>
      </template>
      <template #body>
        <GroupForm
            :formData="groupForm"
            @submit="saveGroup"
            @reset="resetGroupForm"
        />
      </template>
      <template #actions>
        <BaseButton variant="danger" @click="closeGroupModal">Cancel</BaseButton>
      </template>
    </Modal>

    <!-- Time Logs Modal (пример) -->
    <Modal v-if="showTimeLogModal" @close="closeTimeLogModal">
      <template #title>
        <span class="text-xl font-semibold">
          {{ currentTimeLog ? 'Edit Time Log' : 'Add Time Log' }}
        </span>
      </template>
      <template #body>
        <TimeLogForm
            :formData="timeLogForm"
            @submit="saveTimeLog"
            @reset="resetTimeLogForm"
        />
      </template>
      <template #actions>
        <BaseButton variant="danger" @click="closeTimeLogModal">Cancel</BaseButton>
      </template>
    </Modal>
  </div>
</template>

<script>
import api from "@/api";
import Modal from "@/components/Modal.vue";
import TableComponent from "@/components/TableComponent.vue";
import UserForm from "@/components/UserForm.vue";
import GroupForm from "@/components/GroupForm.vue";
import TimeLogForm from "@/components/TimeLogForm.vue"; // если нужно
import BaseButton from "@/components/BaseButton.vue";
import Alert from "@/components/Alert.vue";

export default {
  name: "AdminPanel",
  components: {
    Modal,
    TableComponent,
    UserForm,
    GroupForm,
    TimeLogForm, // если не нужно - уберите
    BaseButton,
    Alert,
  },
  data() {
    return {
      users: [],
      groups: [],
      timeLogs: [], // Если нужны логи
      // Модалки
      showUserModal: false,
      showGroupModal: false,
      showTimeLogModal: false,
      // Текущие объекты
      currentUser: null,
      currentGroup: null,
      currentTimeLog: null,
      // Флаги "редактирования"
      isEditingUser: false,
      isEditingGroup: false,
      // Формы
      userForm: {
        id: null,
        name: "",
        login: "",
        password: "",
        role: "user",
        group_id: null,
      },
      groupForm: {
        id: null,
        group_name: "",
      },
      timeLogForm: {
        id: null,
        user_id: "",
        event_id: "",
        acted_at: "",
      },
      // Alert
      alert: {
        show: false,
        type: "success",
        title: "",
        message: "",
      },
    };
  },
  methods: {
    // Загрузка данных
    async fetchData() {
      try {
        const [usersRes, groupsRes] = await Promise.all([
          api.get("/api/admin/users"),
          api.get("/api/admin/groups"),
          // Если нужно: api.get("/api/admin/userTimeLogs"),
        ]);
        this.users = usersRes.data.data || usersRes.data;
        this.groups = groupsRes.data.data || groupsRes.data;
        // this.timeLogs = timeLogsRes.data.data || timeLogsRes.data;
      } catch (error) {
        console.error("Ошибка загрузки данных:", error);
        this.triggerAlert("error", "Ошибка", "Не удалось загрузить данные.");
      }
    },

    // === USERS ===
    openUserModal(user = null) {
      this.isEditingUser = !!user;
      this.currentUser = user;
      if (user) {
        // Редактируем
        this.userForm = {
          id: user.id,
          name: user.name || "",
          login: user.login || "",
          password: "",
          role: (user.role_id === 1 || user.role_name === "Admin") ? "admin" : "user",
          group_id: user.group_id || null,
        };
      } else {
        // Создаём
        this.userForm = {
          id: null,
          name: "",
          login: "",
          password: "",
          role: "user",
          group_id: null,
        };
      }
      this.showUserModal = true;
    },
    closeUserModal() {
      this.showUserModal = false;
      this.resetUserForm();
    },
    resetUserForm() {
      this.isEditingUser = false;
      this.currentUser = null;
      this.userForm = {
        id: null,
        name: "",
        login: "",
        password: "",
        role: "user",
        group_id: null,
      };
    },
    async saveUser() {
      try {
        if (this.isEditingUser && this.userForm.id) {
          // PUT
          await api.put(`/api/admin/users/${this.userForm.id}`, this.userForm);
          this.triggerAlert("success", "Успешно", "Пользователь обновлен.");
        } else {
          // POST
          await api.post("/api/admin/users", this.userForm);
          this.triggerAlert("success", "Успешно", "Пользователь добавлен.");
        }
        this.fetchData();
        this.closeUserModal();
      } catch (error) {
        console.error("Ошибка сохранения пользователя:", error);
        this.triggerAlert("error", "Ошибка", "Не удалось сохранить пользователя.");
      }
    },
    editUser(user) {
      this.openUserModal(user);
    },
    async deleteUser(userId) {
      if (confirm("Are you sure you want to delete this user?")) {
        try {
          await api.delete(`/api/admin/users/${userId}`);
          this.triggerAlert("success", "Успешно", "Пользователь удален.");
          this.fetchData();
        } catch (error) {
          console.error("Ошибка удаления пользователя:", error);
          this.triggerAlert("error", "Ошибка", "Не удалось удалить пользователя.");
        }
      }
    },

    // === GROUPS ===
    openGroupModal(group = null) {
      this.isEditingGroup = !!group;
      this.currentGroup = group;
      if (group) {
        this.groupForm = {
          id: group.id,
          group_name: group.group_name || "",
        };
      } else {
        this.groupForm = { id: null, group_name: "" };
      }
      this.showGroupModal = true;
    },
    closeGroupModal() {
      this.showGroupModal = false;
      this.resetGroupForm();
    },
    resetGroupForm() {
      this.isEditingGroup = false;
      this.currentGroup = null;
      this.groupForm = { id: null, group_name: "" };
    },
    async saveGroup() {
      try {
        if (this.isEditingGroup && this.groupForm.id) {
          // PUT
          await api.put(`/api/admin/groups/${this.groupForm.id}`, this.groupForm);
          this.triggerAlert("success", "Успешно", "Группа обновлена.");
        } else {
          // POST
          await api.post("/api/admin/groups", this.groupForm);
          this.triggerAlert("success", "Успешно", "Группа добавлена.");
        }
        this.fetchData();
        this.closeGroupModal();
      } catch (error) {
        console.error("Ошибка сохранения группы:", error);
        this.triggerAlert("error", "Ошибка", "Не удалось сохранить группу.");
      }
    },
    editGroup(group) {
      this.openGroupModal(group);
    },
    async deleteGroup(groupId) {
      if (confirm("Are you sure you want to delete this group?")) {
        try {
          await api.delete(`/api/admin/groups/${groupId}`);
          this.triggerAlert("success", "Успешно", "Группа удалена.");
          this.fetchData();
        } catch (error) {
          console.error("Ошибка удаления группы:", error);
          this.triggerAlert("error", "Ошибка", "Не удалось удалить группу.");
        }
      }
    },

    // === TIME LOGS (пример) ===
    openTimeLogModal(timeLog = null) {
      this.currentTimeLog = timeLog;
      if (timeLog) {
        // Редактирование
        this.timeLogForm = { ...timeLog };
      } else {
        // Создание
        this.timeLogForm = { id: null, user_id: "", event_id: "", acted_at: "" };
      }
      this.showTimeLogModal = true;
    },
    closeTimeLogModal() {
      this.showTimeLogModal = false;
      this.resetTimeLogForm();
    },
    resetTimeLogForm() {
      this.currentTimeLog = null;
      this.timeLogForm = { id: null, user_id: "", event_id: "", acted_at: "" };
    },
    async saveTimeLog() {
      try {
        if (this.timeLogForm.id) {
          // PUT
          await api.put(`/api/admin/userTimeLogs/${this.timeLogForm.id}`, this.timeLogForm);
          this.triggerAlert("success", "Успешно", "Таймлог обновлен.");
        } else {
          // POST
          await api.post("/api/admin/userTimeLogs", this.timeLogForm);
          this.triggerAlert("success", "Успешно", "Таймлог добавлен.");
        }
        this.fetchData();
        this.closeTimeLogModal();
      } catch (error) {
        console.error("Ошибка сохранения таймлога:", error);
        this.triggerAlert("error", "Ошибка", "Не удалось сохранить таймлог.");
      }
    },
    async deleteTimeLog(timeLogId) {
      if (confirm("Are you sure you want to delete this time log?")) {
        try {
          await api.delete(`/api/admin/userTimeLogs/${timeLogId}`);
          this.triggerAlert("success", "Успешно", "Таймлог удален.");
          this.fetchData();
        } catch (error) {
          console.error("Ошибка удаления таймлога:", error);
          this.triggerAlert("error", "Ошибка", "Не удалось удалить таймлог.");
        }
      }
    },

    // === ALERT ===
    triggerAlert(type, title, message) {
      this.alert = { show: true, type, title, message };
      setTimeout(() => {
        this.alert.show = false;
      }, 3000);
    },
  },
  mounted() {
    this.fetchData();
  },
};
</script>

<style scoped>
/* стили, как у вас */
.fade-in {
  animation: fadeInUp 0.6s ease forwards;
}
@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
.panel-container {
  background: rgba(255, 255, 255, 0.05);
  backdrop-filter: blur(8px);
  border-radius: 1rem;
  padding: 1.5rem;
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  box-shadow: 0 4px 12px rgba(0,0,0,0.3);
  margin-bottom: 2rem;
}
.hover-card:hover {
  transform: translateY(-3px) scale(1.01);
  box-shadow: 0 8px 20px rgba(0,0,0,0.4);
}
.panel-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
}
.panel-title {
  font-size: 1.75rem;
  font-weight: 600;
  color: #fff;
}
</style>
