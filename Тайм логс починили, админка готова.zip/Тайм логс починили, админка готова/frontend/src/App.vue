<template>
    <div>
        <router-view />
    </div>
</template>

<script>
export default {
    name: "App",
};
</script>

<style>
/* Глобальные стили можно определить здесь или подключить через Tailwind */
</style>
