import { createApp } from 'vue';
import App from './pages/App.vue';
import router from './router/index.js';
import axios from 'axios';
axios.defaults.withCredentials = true;

// Импорт animate.css для глобального использования
import 'animate.css';

// Создаем Vue-приложение, подключаем роутер
const app = createApp(App);
app.use(router);
app.mount('#app');
