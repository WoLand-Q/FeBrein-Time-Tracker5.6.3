import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';
import vue from '@vitejs/plugin-vue';
import path from 'path';

export default defineConfig({
    plugins: [
        laravel({
            input: ['frontend/src/main.js'],
            refresh: true,
        }),
        vue(),
    ],
    resolve: {
        alias: {
            '@': path.resolve(__dirname, './frontend/src'),
            '@layouts': path.resolve(__dirname, './frontend/src/layouts'),
            '@pages': path.resolve(__dirname, './frontend/src/pages'),
            '@components': path.resolve(__dirname, './frontend/src/components'),
            '@assets': path.resolve(__dirname, './frontend/src/assets'),
        },
    },
});
