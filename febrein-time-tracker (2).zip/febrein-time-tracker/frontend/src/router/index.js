import { createRouter, createWebHistory } from 'vue-router';
import BaseLayout from '@layouts/BaseLayout.vue';
import Dashboard from '@pages/Dashboard.vue';
import AdminPage from '@pages/AdminPage.vue';

const routes = [
    {
        path: '/',
        component: BaseLayout,
        children: [
            { path: 'dashboard', component: Dashboard, name: 'dashboard' },
            { path: 'admin', component: AdminPage, name: 'admin' },
        ],
    },
];

const router = createRouter({
    history: createWebHistory(),
    routes,
});

export default router;
