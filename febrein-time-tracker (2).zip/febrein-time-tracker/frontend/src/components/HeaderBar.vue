<template>
    <header class="header-bar">
        <h1>Header Bar</h1>
    </header>
</template>

<script>
export default {
    name: 'HeaderBar',
};
</script>

<style scoped>
.header-bar {
    background-color: #1f1f1f;
    color: #fff;
    padding: 1rem;
    text-align: center;
    font-size: 1.5rem;
}
</style>
