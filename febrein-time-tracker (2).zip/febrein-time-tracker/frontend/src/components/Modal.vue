<!-- components/Modal.vue -->
<template>
    <transition name="modal">
        <div class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
            <div class="modal-content bg-gray-800 text-white p-6 rounded-lg shadow-lg max-w-lg w-full">
                <div class="modal-header mb-4">
                    <slot name="title"></slot>
                </div>
                <div class="modal-body">
                    <slot name="body"></slot>
                </div>
                <div class="modal-actions mt-6 flex justify-end space-x-2">
                    <slot name="actions"></slot>
                </div>
            </div>
        </div>
    </transition>
</template>

<script>
export default {
    name: "Modal",
};
</script>

<style scoped>
.modal-enter-active,
.modal-leave-active {
    @apply transition-opacity duration-300;
}
.modal-enter,
.modal-leave-to {
    @apply opacity-0;
}

</style>
