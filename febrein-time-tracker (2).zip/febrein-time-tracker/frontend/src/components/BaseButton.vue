<!-- components/BaseButton.vue -->
<template>
    <button
        :type="type"
        :class="buttonClasses"
        @click="$emit('click')"
    >
        <slot></slot>
    </button>
</template>

<script>
export default {
    name: "BaseButton",
    props: {
        type: {
            type: String,
            default: "button",
        },
        variant: {
            type: String,
            default: "primary", // варианты: primary, secondary, danger, success, warning
        },
        size: {
            type: String,
            default: "md", // варианты: sm, md, lg
        },
    },
    computed: {
        buttonClasses() {
            const base =
                "inline-flex justify-center font-semibold rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 transition-colors duration-300";
            const variants = {
                primary: "bg-primary hover:bg-primary-dark text-white focus:ring-primary",
                secondary:
                    "bg-secondary hover:bg-secondary-dark text-white focus:ring-secondary",
                danger: "bg-danger hover:bg-danger-dark text-white focus:ring-danger",
                success: "bg-success hover:bg-success-dark text-white focus:ring-success",
                warning: "bg-warning hover:bg-warning-dark text-gray-800 focus:ring-warning",
            };
            const sizes = {
                sm: "px-3 py-1 text-sm",
                md: "px-4 py-2 text-md",
                lg: "px-5 py-3 text-lg",
            };
            return `${base} ${variants[this.variant] || variants.primary} ${sizes[this.size] || sizes.md}`;
        },
    },
};
</script>

<style scoped>
/* Нет необходимости в дополнительных стилях благодаря Tailwind CSS */
</style>
