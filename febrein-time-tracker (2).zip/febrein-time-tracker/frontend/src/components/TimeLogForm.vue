<!-- components/TimeLogForm.vue -->
<template>
    <form @submit.prevent="submitForm" class="space-y-6">
        <div>
            <label for="description" class="block text-sm font-medium text-gray-300">Description</label>
            <input
                v-model="formData.description"
                id="description"
                type="text"
                required
                class="mt-1 block w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-warning focus:border-warning text-white placeholder-gray-400"
                placeholder="Enter description"
            />
            <p v-if="errors.description" class="mt-1 text-sm text-red-600 animate__animated animate__fadeIn">
                {{ errors.description }}
            </p>
        </div>

        <div>
            <label for="duration" class="block text-sm font-medium text-gray-300">Duration (in hours)</label>
            <input
                v-model="formData.duration"
                id="duration"
                type="number"
                min="0"
                step="0.1"
                required
                class="mt-1 block w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-warning focus:border-warning text-white placeholder-gray-400"
                placeholder="e.g., 1.5"
            />
            <p v-if="errors.duration" class="mt-1 text-sm text-red-600 animate__animated animate__fadeIn">
                {{ errors.duration }}
            </p>
        </div>

        <div class="flex justify-end space-x-2">
            <BaseButton type="submit" variant="warning">Save</BaseButton>
            <BaseButton type="button" variant="danger" @click="resetForm">Reset</BaseButton>
        </div>
    </form>
</template>

<script>
import BaseButton from "./BaseButton.vue";

export default {
    name: "TimeLogForm",
    components: { BaseButton },
    props: {
        formData: {
            type: Object,
            default: () => ({
                description: "",
                duration: 0,
            }),
        },
    },
    data() {
        return {
            errors: {},
        };
    },
    methods: {
        submitForm() {
            this.errors = {};
            let isValid = true;

            if (!this.formData.description) {
                this.errors.description = "Description is required.";
                isValid = false;
            }

            if (this.formData.duration === "" || this.formData.duration === null) {
                this.errors.duration = "Duration is required.";
                isValid = false;
            } else if (this.formData.duration < 0) {
                this.errors.duration = "Duration cannot be negative.";
                isValid = false;
            }

            if (isValid) {
                this.$emit("submit", this.formData);
            }
        },
        resetForm() {
            this.$emit("reset");
        },
    },
};
</script>

<style scoped>
/* Нет необходимости в дополнительных стилях благодаря Tailwind CSS */
</style>
