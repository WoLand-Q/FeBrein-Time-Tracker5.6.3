<?php

use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\GroupController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Admin\UserTimeLogController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
require __DIR__.'/auth.php';


Route::middleware(['auth:sanctum', 'admin'])
    ->prefix('admin')
    ->group(function () {
        Route::get('user', function (Request $request) {
            return $request->user();
        })->name('home');
        Route::apiResource('groups',GroupController::class);
        Route::apiResource('users',UserController::class);
        Route::apiResource('userTimeLogs',UserTimeLogController::class);
        Route::get('/dashboard', [DashboardController::class, 'index']);
    });


